#ifndef CUSTOMER_H_INCLUDED
#define CUSTOMER_H_INCLUDED

#include <windows.h>

using namespace std;

class Customer{
    public:
    string firstname;
    string lastname;
    string address;
    int phone;
};

#endif // CUSTOMER_H_INCLUDED
